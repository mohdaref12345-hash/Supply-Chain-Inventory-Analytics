# Supply Chain & Inventory Analytics

A portfolio project exploring inventory, sales, supplier, and warehouse performance using SQL, Excel, Python notebooks, and a browser-based dashboard.

> **Source transparency:** The raw dataset and original analytical project are preserved under `original_source/`. This package includes supplementary portfolio analysis and presentation assets. Do not represent the source project or dataset as originally authored by you.

## Project structure

```text
.
├── README.md
├── Supply_Chain_Inventory_Analytics_Analysis.xlsx
├── dashboard/
│   └── index.html
├── sql/
│   ├── 01_create_table.sql
│   ├── 02_core_kpis.sql
│   ├── 03_analytical_views.sql
│   └── 04_data_quality_checks.sql
├── original_source/
│   ├── README.md
│   ├── data/raw/supply_chain_dataset.csv
│   ├── docs/
│   ├── notebooks/
│   ├── reports/
│   └── sql/                 # source SQL kept separately
├── docs/
│   ├── portfolio_summary.md
│   └── powerbi_guide.md
├── reports/
│   └── final_report.pdf
└── assets/
    └── Supply_Chain_Inventory_Dashboard.png
```

## Highlights

- SQL table setup, KPI queries, analytical views, and data-quality checks.
- Excel analysis workbook.
- Python notebooks for data profiling and business analysis (`original_source/notebooks/`).
- Interactive HTML dashboard (`dashboard/index.html`).
- Final report and Power BI recreation guide.

## Quick start

1. Clone or download this repository.
2. Open `dashboard/index.html` in a modern browser to view the dashboard.
3. Open the Excel workbook for the analysis.
4. For the SQL workflow, create a PostgreSQL database and follow the scripts in `sql/`.
5. Review `docs/powerbi_guide.md` to recreate the report in Power BI Desktop.

### SQL load sequence

1. Run `sql/01_create_table.sql`.
2. Import `original_source/data/raw/supply_chain_dataset.csv` into the `supply_chain` table using your PostgreSQL client.
3. Run `sql/04_data_quality_checks.sql`.
4. Run `sql/02_core_kpis.sql` and `sql/03_analytical_views.sql`.

## Data provenance and interpretation notes

The source dataset and original project are attributed to [HarshilNarola/supply-chain-inventory-analytics](https://github.com/HarshilNarola/supply-chain-inventory-analytics). Refer to the original README and documentation for source-project details.

- Reorder risk is defined as `Inventory_Level < Reorder_Point`; it counts observations, not distinct SKUs.
- Inventory coverage is an approximate row-level ratio, not a statistically forecasted days-of-cover measure; it is undefined when units sold is zero.
- Summing inventory values across repeated daily observations may double-count snapshots; it should not automatically be interpreted as point-in-time inventory valuation.
- Dataset currency is not explicitly specified; monetary values should be treated as generic monetary units.
- The package includes an HTML dashboard and Power BI guide; it does **not** claim to include a native `.pbix` file.

## License and reuse

Check the license and attribution terms in `original_source/README.md` before reusing dataset or source-project materials.
