-- PostgreSQL schema for the original supply-chain dataset
CREATE TABLE IF NOT EXISTS supply_chain (
    date DATE,
    sku_id TEXT,
    warehouse_id TEXT,
    supplier_id TEXT,
    region TEXT,
    units_sold INTEGER,
    inventory_level INTEGER,
    supplier_lead_time_days INTEGER,
    reorder_point INTEGER,
    order_quantity INTEGER,
    unit_cost NUMERIC(12,2),
    unit_price NUMERIC(12,2),
    promotion_flag INTEGER,
    stockout_flag INTEGER,
    demand_forecast NUMERIC(12,2)
);
